<?php
    $container = 'container-xxl';
    $containerNav = 'container-xxl';
?>



<?php $__env->startSection('title', 'Daftar Tagihan'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Layout Demo -->
    <div class="layout-demo-wrapper">
        <div clas="bg-white w-100" style="width: 100%">
            <div class="row">
                <div class="col mt-3">
                    <div class="card">
                        <h5 class="card-header">Daftar Tagihan Perbulan</h5>
                        <form action="<?php echo e(route('pengelolaan-daftar-tagihan')); ?>" method="GET">
                            <div class="d-flex card-body align-items-center gap-3">
                                <div>
                                    <div class="form-check form-switch mb-2">
                                        <input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault"
                                            <?php echo e(request()->get('status_bayar') == 'on' ? 'checked' : ''); ?>

                                            name="status_bayar">
                                        <label class="form-check-label" for="flexSwitchCheckDefault"> Filter Sudah
                                            Dibayar</label>
                                    </div>
                                </div>
                                <div>
                                    <div class="form-floating form-floating-outline">
                                        <input class="form-control" list="datalistOptions" id="exampleDataList"
                                            value="<?php echo e(request()->get('bulan_tagihan')); ?>" name="bulan_tagihan"
                                            placeholder="Pilih Bulan Tagihan">
                                        <datalist id="datalistOptions">
                                            <option value="Januari"></option>
                                            <option value="Februari"></option>
                                            <option value="Maret"></option>
                                            <option value="April"></option>
                                            <option value="Mei"></option>
                                            <option value="Juni"></option>
                                            <option value="Juli"></option>
                                            <option value="Agustus"></option>
                                            <option value="September"></option>
                                            <option value="Oktober"></option>
                                            <option value="Novenmber"></option>
                                            <option value="Desember"></option>
                                        </datalist>
                                        <label for="exampleDataList">Bulan Tagihan</label>
                                    </div>
                                </div>
                                <div>
                                    <div class="form-floating form-floating-outline">
                                        <input class="form-control" list="listTahun" id="exampleDataList"
                                            value="<?php echo e(request()->get('tahun_tagihan')); ?>" name="tahun_tagihan"
                                            placeholder="Pilih Tahun Tagihan">
                                        <datalist id="listTahun">
                                            <option value="2019"></option>
                                            <option value="2020"></option>
                                            <option value="2021"></option>
                                            <option value="2022"></option>
                                            <option value="2023"></option>
                                            <option value="2024"></option>
                                            <option value="2025"></option>
                                            <option value="2026"></option>
                                            <option value="2027"></option>
                                            <option value="2028"></option>
                                            <option value="2029"></option>
                                            <option value="2030"></option>
                                        </datalist>
                                        <label for="exampleDataList">Tahun Tagihan</label>
                                    </div>
                                </div>
                                <div>
                                    <button type="submit" class="btn btn-primary">Cari</button>
                                    <button type="button" class="btn btn-warning"
                                        onclick="location.href='<?php echo e(route('pengelolaan-daftar-tagihan')); ?>'">Reset</button>
                                </div>
                            </div>
                        </form>
                        <?php if($list_tagihan): ?>
                            <div class="table-responsive text-nowrap">
                                <div class="mx-3">
                                    <p>Filter diterapkan untuk Bulan <?php echo e(request()->get('bulan_tagihan')); ?>

                                        <?php echo e(request()->get('tahun_tagihan')); ?>

                                        [<?php echo e(request()->get('status_bayar') == 'on' ? 'Sudah Dibayar' : 'Belum Dibayar'); ?>]
                                    </p>
                                </div>
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>ID Pelanggan</th>
                                            <th>Nama Pelanggan</th>
                                            <th>Bulan Tagihan</th>
                                            <th>Jumlah Meter</th>
                                            <th>Jumlah Bayar</th>
                                            <th>Status</th>
                                            <th>Petugas</th>
                                        </tr>
                                    </thead>
                                    <tbody class="table-border-bottom-0">
                                        <?php
                                            $no = 1;
                                        ?>
                                        <?php $__currentLoopData = $list_tagihan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tagihan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($no); ?></td>
                                                <td><?php echo e($tagihan->id_pelanggan); ?></td>
                                                <td><?php echo e($tagihan->nama_pelanggan); ?></td>
                                                <td><?php echo e($tagihan->bulan_tagihan); ?></td>
                                                <td><?php echo e($tagihan->meter_akhir - $tagihan->meter_awal); ?></td>
                                                <td>Rp. <?php echo e(number_format($tagihan->jumlah_bayar, 0, ',', '.')); ?></td>
                                                <td><?php echo $tagihan->status_bayar
                                                    ? '<span class="badge rounded-pill bg-success">Sudah dibayar</span>'
                                                    : '<span class="badge rounded-pill bg-danger">Belum dibayar</span>'; ?>

                                                </td>
                                                <td><?php echo e($tagihan->petugas); ?></td>
                                            </tr>
                                            <?php
                                                $no++;
                                            ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--/ Layout Demo -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sbuhmpm/development/project_ivan/sendangguwo/materio-bootstrap-html-laravel-admin-template-free-v1.0.0/resources/views/content/menu-admin/laporan-tagihan-perbulan.blade.php ENDPATH**/ ?>