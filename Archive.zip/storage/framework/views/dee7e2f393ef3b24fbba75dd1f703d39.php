<?php
    $container = 'container-xxl';
    $containerNav = 'container-xxl';
?>



<?php $__env->startSection('title', 'Kelola Akun'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Layout Demo -->
    <div class="layout-demo-wrapper">
        <div clas="bg-white w-100" style="width: 100%">
            <div class="row">
                <div class="col-4">
                    <div class="card h-100 mt-3">
                        <div class="card-body">
                            <h5 class="card-title">Data Akun</h5>
                            <h6 class="card-subtitle text-muted">Informasi detail data akun</h6>
                        </div>
                        <div class="card-body">
                            <?php if(!$initial_user): ?>
                                <form method="POST" action="<?php echo e(route('datamaster-tambah-akun')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-floating form-floating-outline mb-4">
                                        <input type="text" class="form-control" id="basic-default-company" required
                                            name="username" placeholder="Masukan Username Petugas" />
                                        <label for="basic-default-company">Username<span
                                                style="color: red;">*</span></label>
                                    </div>
                                    <div class="form-floating form-floating-outline mb-4">
                                        <input type="text" class="form-control" id="basic-default-company" required
                                            name="password" placeholder="Masukan Password Petugas" />
                                        <label for="basic-default-company">Password<span
                                                style="color: red;">*</span></label>
                                    </div>
                                    <div class="form-floating form-floating-outline mb-4">
                                        <input type="text" class="form-control" id="basic-default-company"
                                            name="no_telepon" placeholder="Masukan Nomor telepon Petugas" />
                                        <label for="basic-default-company">Nomor Telepon</label>
                                    </div>
                                    <div class="form-floating form-floating-outline mb-4">
                                        <input class="form-control" list="datalistOptions" id="exampleDataList" required
                                            name="role" placeholder="Pilih Role Akun">
                                        <datalist id="datalistOptions">
                                            <option value="Admin"></option>
                                            <option value="Petugas"></option>
                                        </datalist>
                                        <label for="exampleDataList">Role<span style="color: red;">*</span></label>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                </form>
                            <?php else: ?>
                                <form method="POST" action="<?php echo e(route('datamaster-ubah-akun', $initial_user->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="form-floating form-floating-outline mb-4">
                                        <input type="text" class="form-control" id="basic-default-company" required
                                            name="username" value="<?php echo e($initial_user->username); ?>"
                                            placeholder="Masukan Username Petugas" />
                                        <label for="basic-default-company">Username<span
                                                style="color: red;">*</span></label>
                                    </div>
                                    <div class="form-floating form-floating-outline mb-4">
                                        <input type="text" class="form-control" id="basic-default-company" required
                                            name="password" placeholder="Masukan Password Petugas" />
                                        <label for="basic-default-company">Password<span
                                                style="color: red;">*</span></label>
                                    </div>
                                    <div class="form-floating form-floating-outline mb-4">
                                        <input type="text" class="form-control" id="basic-default-company"
                                            name="no_telepon" value="<?php echo e($initial_user->no_telepon); ?>"
                                            placeholder="Masukan Nomor telepon Petugas" />
                                        <label for="basic-default-company">Nomor Telepon</label>
                                    </div>
                                    <div class="form-floating form-floating-outline mb-4">
                                        <input class="form-control" list="datalistOptions" id="exampleDataList" required
                                            name="role" value="<?php echo e($initial_user->role); ?>" placeholder="Pilih Role Akun">
                                        <datalist id="datalistOptions">
                                            <option value="Admin"></option>
                                            <option value="Petugas"></option>
                                        </datalist>
                                        <label for="exampleDataList">Role<span style="color: red;">*</span></label>
                                    </div>
                                    <div>
                                        <button type="submit" class="btn btn-warning">Ubah</button>
                                        <button type="button" class="btn btn-danger"
                                            onclick="location.href='<?php echo e(route('datamaster-kelola-akun')); ?>'">Batal</button>
                                    </div>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-8 mt-3">
                    <div class="card">
                        <h5 class="card-header">Daftar Akun</h5>
                        <div class="table-responsive text-nowrap">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Username</th>
                                        <th>No Telepon</th>
                                        <th>Role</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody class="table-border-bottom-0">
                                    <?php
                                        $no = 1;
                                    ?>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($no); ?></td>
                                            <td><?php echo e($user->username); ?></td>
                                            <td><?php echo e($user->no_telepon); ?></td>
                                            <td><?php echo $user->role == 'Admin'
                                                ? '<span style="width: 70px;" class="badge rounded-pill bg-success">Admin</span>'
                                                : '<span style="width: 70px;" class="badge rounded-pill bg-info">Petugas</span>'; ?></td>
                                            <td>
                                                <div class="d-flex gap-2">
                                                    <form action="<?php echo e(route('datamaster-kelola-akun', $user->id)); ?>">
                                                        <?php echo method_field('GET'); ?>
                                                        <button type="sumbit" class="btn btn-warning">Edit</button>
                                                    </form>
                                                    <form method="POST"
                                                        action="<?php echo e(route('datamaster-hapus-akun', $user->id)); ?>"
                                                        onsubmit="return confirm('Apakah Anda yakin ingin menghapus data ini?');">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-danger">Delete</button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php
                                            $no++;
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--/ Layout Demo -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sbuhmpm/development/project_ivan/sendangguwo/materio-bootstrap-html-laravel-admin-template-free-v1.0.0/resources/views/content/menu-admin/kelola-akun.blade.php ENDPATH**/ ?>