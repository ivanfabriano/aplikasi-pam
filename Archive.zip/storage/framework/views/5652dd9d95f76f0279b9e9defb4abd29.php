<?php
    $container = 'container-xxl';
    $containerNav = 'container-xxl';
?>



<?php $__env->startSection('title', 'Beranda'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Layout Demo -->
    <div class="layout-demo-wrapper">
        <img class="mb-4" src="<?php echo e(asset('assets/img/logos/logo1.png')); ?>" alt="Logo" width="180px">
        <h3 class="text-center">Selamat Datang di Aplikasi <br>Pembayaran Pengelolaan Air Bersih</h3>
    </div>
    <!--/ Layout Demo -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sbuhmpm/development/project_ivan/sendangguwo/materio-bootstrap-html-laravel-admin-template-free-v1.0.0/resources/views/content/menu-admin/home-page.blade.php ENDPATH**/ ?>