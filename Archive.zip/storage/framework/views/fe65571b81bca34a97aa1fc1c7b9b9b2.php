<?php
    $container = 'container-xxl';
    $containerNav = 'container-xxl';
?>



<?php $__env->startSection('title', 'Kelola Pelanggan'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Layout Demo -->
    <div class="layout-demo-wrapper">
        <div clas="bg-white w-100" style="width: 100%">
            <div class="row">
                <div class="col-3">
                    <div class="card h-100 mt-3">
                        <div class="card-body">
                            <h5 class="card-title">Data Pelanggan</h5>
                            <h6 class="card-subtitle text-muted mb-5">Isian dengan tanda <span style="color: red;">*</span>
                                wajib
                                diisi</h6>
                            <?php if(!$initial_pelanggan): ?>
                                <form method="POST" action="<?php echo e(route('datamaster-tambah-pelanggan')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-floating form-floating-outline mb-4">
                                        <input type="text" class="form-control" id="basic-default-company" readonly
                                            value="<?php echo e($last_id_pelanggan); ?>" name="id_pelanggan"
                                            placeholder="Masukan ID Pelanggan" />
                                        <label for="basic-default-company">ID Pelanggan<span
                                                style="color: red;">*</span></label>
                                    </div>
                                    <div class="form-floating form-floating-outline mb-4">
                                        <input type="text" class="form-control" id="basic-default-company" required
                                            name="no_meter" placeholder="Masukan No Meter" />
                                        <label for="basic-default-company">No Meter<span
                                                style="color: red;">*</span></label>
                                    </div>
                                    <div class="form-floating form-floating-outline mb-4">
                                        <input type="text" class="form-control" id="basic-default-company" required
                                            name="nama_pelanggan" placeholder="Masukan Nama Pelanggan" />
                                        <label for="basic-default-company">Nama Pelanggan<span
                                                style="color: red;">*</span></label>
                                    </div>
                                    <div class="form-floating form-floating-outline mb-4">
                                        <textarea class="form-control h-px-100" id="exampleFormControlTextarea1" placeholder="Masukan Alamat Pelanggan" required
                                            name="alamat_pelanggan"></textarea>
                                        <label for="exampleFormControlTextarea1">Alamat Pelanggan<span
                                                style="color: red;">*</span></label>
                                    </div>
                                    <div class="form-floating form-floating-outline mb-4">
                                        <input type="text" class="form-control" id="basic-default-company" required
                                            name="tenggang" placeholder="Masukan Hari Tenggang" />
                                        <label for="basic-default-company">Tenggang Hari Ke<span
                                                style="color: red;">*</span></label>
                                    </div>
                                    <div class="form-floating form-floating-outline mb-4">
                                        <input class="form-control" list="datalistOptions" id="exampleDataList" required
                                            name="jenis_tarif" placeholder="Pilih Jenis Tarif">
                                        <datalist id="datalistOptions">
                                            <?php $__currentLoopData = $tarifs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($tarif->kode_tarif); ?>"></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </datalist>
                                        <label for="exampleDataList">Jenis Tarif<span style="color: red;">*</span></label>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                </form>
                            <?php else: ?>
                                <form method="POST"
                                    action="<?php echo e(route('datamaster-ubah-pelanggan', $initial_pelanggan->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="form-floating form-floating-outline mb-4">
                                        <input type="text" class="form-control" id="basic-default-company" readonly
                                            value="<?php echo e($initial_pelanggan->id_pelanggan); ?>" name="id_pelanggan"
                                            placeholder="Masukan ID Pelanggan" />
                                        <label for="basic-default-company">ID Pelanggan<span
                                                style="color: red;">*</span></label>
                                    </div>
                                    <div class="form-floating form-floating-outline mb-4">
                                        <input type="text" class="form-control" id="basic-default-company" required
                                            value="<?php echo e($initial_pelanggan->no_meter); ?>" name="no_meter"
                                            placeholder="Masukan No Meter" />
                                        <label for="basic-default-company">No Meter<span
                                                style="color: red;">*</span></label>
                                    </div>
                                    <div class="form-floating form-floating-outline mb-4">
                                        <input type="text" class="form-control" id="basic-default-company" required
                                            value="<?php echo e($initial_pelanggan->nama_pelanggan); ?>" name="nama_pelanggan"
                                            placeholder="Masukan Nama Pelanggan" />
                                        <label for="basic-default-company">Nama Pelanggan<span
                                                style="color: red;">*</span></label>
                                    </div>
                                    <div class="form-floating form-floating-outline mb-4">
                                        <textarea class="form-control h-px-100" id="exampleFormControlTextarea1" placeholder="Masukan Alamat Pelanggan" required
                                            name="alamat_pelanggan"><?php echo e($initial_pelanggan->alamat_pelanggan); ?></textarea>
                                        <label for="exampleFormControlTextarea1">Alamat Pelanggan<span
                                                style="color: red;">*</span></label>
                                    </div>
                                    <div class="form-floating form-floating-outline mb-4">
                                        <input type="text" class="form-control" id="basic-default-company" required
                                            value="<?php echo e($initial_pelanggan->tenggang); ?>" name="tenggang"
                                            placeholder="Masukan Hari Tenggang" />
                                        <label for="basic-default-company">Tenggang Hari Ke<span
                                                style="color: red;">*</span></label>
                                    </div>
                                    <div class="form-floating form-floating-outline mb-4">
                                        <input class="form-control" list="datalistOptions" id="exampleDataList" required
                                            value="<?php echo e($initial_pelanggan->jenis_tarif); ?>" name="jenis_tarif"
                                            placeholder="Pilih Jenis Tarif">
                                        <datalist id="datalistOptions">
                                            <?php $__currentLoopData = $tarifs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($tarif->kode_tarif); ?>"></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </datalist>
                                        <label for="exampleDataList">Jenis Tarif<span style="color: red;">*</span></label>
                                    </div>
                                    <div>
                                        <button type="submit" class="btn btn-warning">Ubah</button>
                                        <button type="button" class="btn btn-danger"
                                            onclick="location.href='<?php echo e(route('datamaster-kelola-pelanggan')); ?>'">Batal</button>
                                    </div>
                                </form>
                                <form method="POST"
                                    action="<?php echo e(route('pengelolaan-reset-penggunaan', $initial_pelanggan->id)); ?>"
                                    onsubmit="return confirm('Apakah Anda yakin ingin mereset meter?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('POST'); ?>
                                    <button type="submit" class="btn btn-success mt-2">Reset Meter</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-9 mt-3">
                    <div class="card">
                        <h5 class="card-header">Daftar Pelanggan</h5>
                        <div>
                            <div class="card-body">
                                <div class="d-flex gap-2">
                                    <form class="d-flex gap-2" action="<?php echo e(route('datamaster-kelola-pelanggan')); ?>"
                                        method="GET" style="width: 100%">
                                        <div>
                                            <div class="form-check form-switch">
                                                <input class="form-check-input" type="checkbox" name="telat_bayar"
                                                    <?php echo e(request()->get('telat_bayar') == 'on' ? 'checked' : ''); ?>

                                                    id="flexSwitchCheckDefault">
                                                <label class="form-check-label" for="flexSwitchCheckDefault"> Telat
                                                    Bayar</label>
                                            </div>
                                        </div>

                                        <div class="form-floating form-floating-outline" style="width: 100%">
                                            <input class="form-control" list="identitaspelanggan" id="exampleDataList"
                                                value="<?php echo e(request()->get('id_name_filter')); ?>" name="id_name_filter"
                                                placeholder="Masukan ID atau Nama Pelanggan">
                                            <datalist id="identitaspelanggan">
                                                <?php $__currentLoopData = $list_pelanggans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list_pelanggan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option
                                                        value="<?php echo e($list_pelanggan->id_pelanggan); ?>-<?php echo e($list_pelanggan->nama_pelanggan); ?>">
                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </datalist>
                                            <label for="exampleDataList">Cari Data Pelanggan</label>
                                        </div>
                                        <button type="submit" class="btn btn-primary">Cari</button>
                                        <button type="button" class="btn btn-warning"
                                            onclick="location.href='<?php echo e(route('datamaster-kelola-pelanggan')); ?>'">Reset</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="table-responsive text-nowrap">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>ID Pelanggan</th>
                                        <th>No Meter</th>
                                        <th>Nama</th>
                                        <th>Alamat</th>
                                        <th>Tenggang</th>
                                        <th>Kode Tarif</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody class="table-border-bottom-0">
                                    <?php
                                        $no = 1;
                                    ?>
                                    <?php $__currentLoopData = $pelanggans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelanggan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="<?php echo e($pelanggan->tertunggak ? 'table-danger' : ''); ?>">
                                            <td><?php echo e($no); ?></td>
                                            <td><?php echo e($pelanggan->id_pelanggan); ?></td>
                                            <td><?php echo e($pelanggan->no_meter); ?></td>
                                            <td><?php echo e($pelanggan->nama_pelanggan); ?></td>
                                            <td><?php echo e($pelanggan->alamat_pelanggan); ?></td>
                                            <td>Hari ke-<?php echo e($pelanggan->tenggang); ?></td>
                                            <td><?php echo e($pelanggan->jenis_tarif); ?></td>
                                            <td>
                                                <div class="dropdown">
                                                    <button type="button" class="btn p-0 dropdown-toggle hide-arrow"
                                                        data-bs-toggle="dropdown"><i
                                                            class="mdi mdi-dots-vertical"></i></button>
                                                    <div class="dropdown-menu p-2">
                                                        <div class="d-flex gap-1">
                                                            <form
                                                                action="<?php echo e(route('datamaster-kelola-pelanggan', $pelanggan->id)); ?>">
                                                                <?php echo method_field('GET'); ?>
                                                                <button type="sumbit"
                                                                    class="btn btn-warning">Edit</button>
                                                            </form>
                                                            <form method="POST"
                                                                action="<?php echo e(route('datamaster-hapus-pelanggan', $pelanggan->id)); ?>"
                                                                onsubmit="return confirm('Apakah Anda yakin ingin menghapus data ini?');">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                                <button type="submit"
                                                                    class="btn btn-danger">Delete</button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php
                                            $no++;
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--/ Layout Demo -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sbuhmpm/development/project_ivan/sendangguwo/materio-bootstrap-html-laravel-admin-template-free-v1.0.0/resources/views/content/menu-admin/kelola-pelanggan.blade.php ENDPATH**/ ?>