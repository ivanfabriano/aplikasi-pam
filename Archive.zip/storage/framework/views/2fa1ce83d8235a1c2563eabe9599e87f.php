<?php
    $container = 'container-xxl';
    $containerNav = 'container-xxl';
?>



<?php $__env->startSection('title', 'Kelola Tarif'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Layout Demo -->
    <div class="layout-demo-wrapper">
        <div clas="bg-white w-100" style="width: 100%">
            <div class="row">
                <div class="col-4">
                    <div class="card h-100 mt-3">
                        <div class="card-body">
                            <h5 class="card-title">Data Tarif</h5>
                            <h6 class="card-subtitle text-muted mb-5">Isian dengan tanda <span style="color: red;">*</span>
                                wajib
                                diisi</h6>
                            <?php if(!$initial_tarif): ?>
                                <form method="POST" action="<?php echo e(route('datamaster-tambah-tarif')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-floating form-floating-outline mb-4">
                                        <input type="text" class="form-control" id="basic-default-company" required
                                            name="golongan" placeholder="Masukan Nama Golongan" />
                                        <label for="basic-default-company">Golongan<span
                                                style="color: red;">*</span></label>
                                    </div>
                                    <div class="form-floating form-floating-outline mb-4">
                                        <input type="text" class="form-control" id="basic-default-company" required
                                            name="abonemen" placeholder="Masukan Abonemen" />
                                        <label for="basic-default-company">Abonemen<span
                                                style="color: red;">*</span></label>
                                    </div>
                                    <div class="form-floating form-floating-outline mb-4">
                                        <input type="text" class="form-control" id="basic-default-company" name="tarif"
                                            required placeholder="Masukan Jumlah Tarif" />
                                        <label for="basic-default-company">Tarif<span style="color: red;">*</span></label>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                </form>
                            <?php else: ?>
                                <form method="POST" action="<?php echo e(route('datamaster-ubah-tarif', $initial_tarif->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="form-floating form-floating-outline mb-4">
                                        <input type="text" class="form-control" id="basic-default-company" required
                                            value="<?php echo e($initial_tarif->golongan); ?>" name="golongan"
                                            placeholder="Masukan Nama Golongan" />
                                        <label for="basic-default-company">Golongan<span
                                                style="color: red;">*</span></label>
                                    </div>
                                    <div class="form-floating form-floating-outline mb-4">
                                        <input type="text" class="form-control" id="basic-default-company" required
                                            value="<?php echo e($initial_tarif->abonemen); ?>" name="abonemen"
                                            placeholder="Masukan Abonemen" />
                                        <label for="basic-default-company">Abonemen<span
                                                style="color: red;">*</span></label>
                                    </div>
                                    <div class="form-floating form-floating-outline mb-4">
                                        <input type="text" class="form-control" id="basic-default-company" name="tarif"
                                            required value="<?php echo e($initial_tarif->tarif); ?>"
                                            placeholder="Masukan Jumlah Tarif" />
                                        <label for="basic-default-company">Tarif<span style="color: red;">*</span></label>
                                    </div>
                                    <div>
                                        <button type="submit" class="btn btn-warning">Ubah</button>
                                        <button type="button" class="btn btn-danger"
                                            onclick="location.href='<?php echo e(route('datamaster-kelola-tarif')); ?>'">Batal</button>
                                    </div>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-8 mt-3">
                    <div class="card">
                        <h5 class="card-header">Daftar Tarif</h5>
                        <div class="table-responsive text-nowrap">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Kode Tarif</th>
                                        <th>Golongan</th>
                                        <th>Abonemen</th>
                                        <th>Tarif/M<sup>3</sup></th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody class="table-border-bottom-0">
                                    <?php
                                        $no = 1;
                                    ?>
                                    <?php $__currentLoopData = $tarifs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($no); ?></td>
                                            <td><?php echo e($tarif->kode_tarif); ?></td>
                                            <td><?php echo e($tarif->golongan); ?></td>
                                            <td>Rp. <?php echo e(number_format($tarif->abonemen, 0, ',', '.')); ?></td>
                                            <td>Rp. <?php echo e(number_format($tarif->tarif, 0, ',', '.')); ?></td>
                                            <td>
                                                <div class="d-flex gap-2">
                                                    <form action="<?php echo e(route('datamaster-kelola-tarif', $tarif->id)); ?>">
                                                        <?php echo method_field('GET'); ?>
                                                        <button type="sumbit" class="btn btn-warning">Edit</button>
                                                    </form>
                                                    <form method="POST"
                                                        action="<?php echo e(route('datamaster-hapus-tarif', $tarif->id)); ?>"
                                                        onsubmit="return confirm('Apakah Anda yakin ingin menghapus data ini?');">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-danger">Delete</button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php
                                            $no++;
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--/ Layout Demo -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sbuhmpm/development/project_ivan/sendangguwo/materio-bootstrap-html-laravel-admin-template-free-v1.0.0/resources/views/content/menu-admin/kelola-tarif.blade.php ENDPATH**/ ?>