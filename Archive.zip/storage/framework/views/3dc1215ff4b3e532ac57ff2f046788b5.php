<?php
    $container = 'container-xxl';
    $containerNav = 'container-xxl';
?>



<?php $__env->startSection('title', 'Input Penggunaan'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Layout Demo -->
    <div class="layout-demo-wrapper">
        <div class="col-xl">
            <div class="card mb-4" style="width: 100%">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Form Input Penggunaan</h5>
                </div>
                <div class="card-body">
                    <?php if(!$pelanggan): ?>
                        <form action="<?php echo e(route('pengelolaan-input-penggunaan')); ?>" method="GET">
                            <div class="d-flex mb-4 gap-2">
                                <div class="form-floating form-floating-outline" style="width: 100%">
                                    <input class="form-control" list="datalistOptions" id="exampleDataList"
                                        <?php echo e($pelanggan ? 'readonly' : ''); ?>

                                        value="<?php echo e($pelanggan ? $pelanggan->id_pelanggan : ''); ?>" name="id_pelanggan"
                                        placeholder="Type to search...">
                                    <datalist id="datalistOptions">
                                        <?php $__currentLoopData = $list_pelanggans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list_pelanggan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option
                                                value="<?php echo e($list_pelanggan->id_pelanggan); ?>-<?php echo e($list_pelanggan->nama_pelanggan); ?>">
                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </datalist>
                                    <label for="exampleDataList">ID Pelanggan<span style="color: red;">*</span></label>
                                </div>
                                <button type="submit" class="btn btn-primary">Cari</button>
                            </div>
                            <div class="form-floating form-floating-outline mb-4">
                                <input type="text" class="form-control" id="basic-default-company" readonly
                                    name="no_meter" value="<?php echo e($pelanggan ? $pelanggan->no_meter : ''); ?>"
                                    placeholder="Masukan No Meter" />
                                <label for="basic-default-company">Nomor Meter<span style="color: red;">*</span></label>
                            </div>
                            <div class="form-floating form-floating-outline mb-4">
                                <input type="text" class="form-control" id="basic-default-company" readonly
                                    name="nama_pelanggan" value="<?php echo e($pelanggan ? $pelanggan->nama_pelanggan : ''); ?>"
                                    placeholder="Masukan Nama Pelanggan" />
                                <label for="basic-default-company">Nama Pelanggan<span style="color: red;">*</span></label>
                            </div>
                            <div class="form-floating form-floating-outline mb-4">
                                <input type="text" class="form-control" id="basic-default-company" readonly
                                    name="bulan_penggunaan" value="<?php echo e($pelanggan ? $pelanggan->bulan_penggunaan : ''); ?>"
                                    placeholder="Masukan Bulan Pengggunaan" />
                                <label for="basic-default-company">Bulan Penggunaan<span
                                        style="color: red;">*</span></label>
                            </div>
                            <div class="form-floating form-floating-outline mb-4">
                                <input class="form-control" type="number" placeholder="18" id="html5-number-input" readonly
                                    name="meter_awal" value="<?php echo e($pelanggan ? $pelanggan->meter_awal : ''); ?>" />
                                <label for="html5-number-input">Meter Awal<span style="color: red;">*</span></label>
                            </div>
                            <div class="form-floating form-floating-outline mb-4">
                                <input class="form-control" type="number" placeholder="18" id="html5-number-input"
                                    name="meter_akhir" />
                                <label for="html5-number-input">Meter Akhir<span style="color: red;">*</span></label>
                            </div>
                            <div class="form-floating form-floating-outline mb-4">
                                <input class="form-control" type="date" id="html5-date-input"
                                    name="tanggal_pengecekan" />
                                <label for="html5-date-input">Tanggal Pengecekan<span style="color: red;">*</span></label>
                            </div>
                        </form>
                    <?php else: ?>
                        <form action="<?php echo e(route('pengelolaan-tambah-penggunaan')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="d-flex mb-4 gap-2">
                                <div class="form-floating form-floating-outline" style="width: 100%">
                                    <input class="form-control" list="datalistOptions" id="exampleDataList" required
                                        <?php echo e($pelanggan ? 'readonly' : ''); ?>

                                        value="<?php echo e($pelanggan ? $pelanggan->id_pelanggan : ''); ?>" name="id_pelanggan"
                                        placeholder="Type to search...">
                                    <datalist id="datalistOptions">
                                        <?php $__currentLoopData = $list_pelanggans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list_pelanggan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option
                                                value="<?php echo e($list_pelanggan->id_pelanggan); ?>-<?php echo e($list_pelanggan->nama_pelanggan); ?>">
                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </datalist>
                                    <label for="exampleDataList">ID Pelanggan<span style="color: red;">*</span></label>
                                </div>
                                <button type="submit" class="btn btn-primary">Cari</button>
                            </div>
                            <div class="form-floating form-floating-outline mb-4">
                                <input type="text" class="form-control" id="basic-default-company" readonly required
                                    name="no_meter" value="<?php echo e($pelanggan ? $pelanggan->no_meter : ''); ?>"
                                    placeholder="Masukan No Meter" />
                                <label for="basic-default-company">Nomor Meter<span style="color: red;">*</span></label>
                            </div>
                            <div class="form-floating form-floating-outline mb-4">
                                <input type="text" class="form-control" id="basic-default-company" readonly required
                                    name="nama_pelanggan" value="<?php echo e($pelanggan ? $pelanggan->nama_pelanggan : ''); ?>"
                                    placeholder="Masukan Nama Pelanggan" />
                                <label for="basic-default-company">Nama Pelanggan<span
                                        style="color: red;">*</span></label>
                            </div>
                            <div class="form-floating form-floating-outline mb-4">
                                <input type="text" class="form-control" id="basic-default-company" readonly required
                                    name="bulan_penggunaan" value="<?php echo e($pelanggan ? $pelanggan->bulan_penggunaan : ''); ?>"
                                    placeholder="Masukan Bulan Pengggunaan" />
                                <label for="basic-default-company">Bulan Penggunaan<span
                                        style="color: red;">*</span></label>
                            </div>
                            <div class="form-floating form-floating-outline mb-4">
                                <input class="form-control" type="number" placeholder="18" id="html5-number-input"
                                    required readonly name="meter_awal"
                                    value="<?php echo e($pelanggan ? $pelanggan->meter_awal : ''); ?>" />
                                <label for="html5-number-input">Meter Awal<span style="color: red;">*</span></label>
                            </div>
                            <div class="form-floating form-floating-outline mb-4">
                                <input class="form-control" type="number" placeholder="18" id="html5-number-input"
                                    required name="meter_akhir" />
                                <label for="html5-number-input">Meter Akhir<span style="color: red;">*</span></label>
                            </div>
                            <div class="form-floating form-floating-outline mb-4">
                                <input class="form-control" type="date" id="html5-date-input" required
                                    name="tanggal_pengecekan" />
                                <label for="html5-date-input">Tanggal Pengecekan<span style="color: red;">*</span></label>
                            </div>
                            <button type="submit" class="btn btn-primary">Simpan</button>
                            <?php if($pelanggan): ?>
                                <button type="button" class="btn btn-danger"
                                    onclick="location.href='<?php echo e(route('pengelolaan-input-penggunaan')); ?>'">Batal</button>
                            <?php endif; ?>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <!--/ Layout Demo -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sbuhmpm/development/project_ivan/sendangguwo/materio-bootstrap-html-laravel-admin-template-free-v1.0.0/resources/views/content/menu-admin/kelola-penggunaan.blade.php ENDPATH**/ ?>