<?php
    $container = 'container-xxl';
    $containerNav = 'container-xxl';
?>



<?php $__env->startSection('title', 'Daftar Tunggakan'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Layout Demo -->
    <div class="layout-demo-wrapper">
        <div clas="bg-white w-100" style="width: 100%">
            <div class="row">
                <div class="col mt-3">
                    <div class="card">
                        <h5 class="card-header">Daftar Tunggakan Pelanggan <span class="text-muted">[Lebih Dari 3
                                Bulan]</span></h5>
                        <div class="table-responsive text-nowrap">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>ID Pelanggan</th>
                                        <th>Nama Pelanggan</th>
                                        <th>Alamat </th>
                                        <th>Banyak Tunggakan</th>
                                        <th>Bulan Tertunggak</th>
                                        <th>Jumlah Meter</th>
                                        <th>Tarif</th>
                                        <th>Jumlah Bayar</th>
                                    </tr>
                                </thead>
                                <tbody class="table-border-bottom-0">
                                    <?php
                                        $no = 1;
                                        $total_bayar = 0;
                                    ?>
                                    <?php $__currentLoopData = $list_tagihan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tagihan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($no); ?></td>
                                            <td><?php echo e($tagihan->id_pelanggan); ?></td>
                                            <td><?php echo e($tagihan->nama_pelanggan); ?></td>
                                            <td><?php echo e($tagihan->alamat_pelanggan); ?></td>
                                            <td><?php echo e($tagihan->banyak_tunggakan); ?> Bulan</td>
                                            <td>
                                                <div class="d-flex flex-wrap gap-1">
                                                    <?php $__currentLoopData = $tagihan->bulan_tertunggak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bulan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <span class="badge bg-info"><?php echo e($bulan); ?></span>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </td>
                                            <td><?php echo e($tagihan->jumlah_meter); ?></td>
                                            <td>Rp. <?php echo e(number_format($tagihan->tarif, 0, ',', '.')); ?></td>
                                            <td>Rp. <?php echo e(number_format($tagihan->jumlah_bayar, 0, ',', '.')); ?></td>
                                        </tr>
                                        <?php
                                            $no++;
                                            $total_bayar += $tagihan->jumlah_bayar;
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--/ Layout Demo -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sbuhmpm/development/project_ivan/sendangguwo/materio-bootstrap-html-laravel-admin-template-free-v1.0.0/resources/views/content/menu-admin/laporan-tunggakan.blade.php ENDPATH**/ ?>