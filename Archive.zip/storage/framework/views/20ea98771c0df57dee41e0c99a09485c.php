<?php
    $container = 'container-xxl';
    $containerNav = 'container-xxl';
?>



<?php $__env->startSection('title', 'Riwayat Transaksi'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Layout Demo -->
    <div class="layout-demo-wrapper">
        <div clas="bg-white w-100" style="width: 100%">
            <div class="row">
                <div class="col mt-3">
                    <div class="card">
                        <h5 class="card-header">Riwayat Transaksi Pelanggan <span
                                class="text-muted">[<?php echo e($info_pelanggan ? $info_pelanggan->id_pelanggan . '-' . $info_pelanggan->nama_pelanggan : 'Semua Pelanggan'); ?>]</span>
                        </h5>
                        <div class="table-responsive text-nowrap">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>ID Pembayaran</th>
                                        <th>ID Pelanggan</th>
                                        <th>Nama Pelanggan </th>
                                        <th>Waktu</th>
                                        <th>Bulan Bayar</th>
                                        <th>Jumlah Bayar</th>
                                        <th>Biaya Admin</th>
                                        <th>Denda</th>
                                        <th>Total Akhir</th>
                                        <th>Bayar</th>
                                        <th>Kembali</th>
                                        <th>Petugas</th>
                                    </tr>
                                </thead>
                                <tbody class="table-border-bottom-0">
                                    <?php
                                        $no = 1;
                                    ?>
                                    <?php $__currentLoopData = $list_tagihan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tagihan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($no); ?></td>
                                            <td><?php echo e($tagihan->id_pembayaran); ?></td>
                                            <td><?php echo e($tagihan->id_pelanggan); ?></td>
                                            <td><?php echo e($tagihan->nama_pelanggan); ?></td>
                                            <td><?php echo e($tagihan->waktu_bayar); ?></td>
                                            <td><?php echo e($tagihan->bulan_tagihan); ?> <?php echo e(explode('-', $tagihan->waktu_bayar)[0]); ?>

                                            </td>
                                            <td>Rp. <?php echo e(number_format($tagihan->jumlah_bayar, 0, ',', '.')); ?></td>
                                            <td>Rp. <?php echo e(number_format($tagihan->biaya_admin, 0, ',', '.')); ?></td>
                                            <td>Rp. <?php echo e(number_format($tagihan->denda, 0, ',', '.')); ?></td>
                                            <td>Rp. <?php echo e(number_format($tagihan->total_akhir, 0, ',', '.')); ?></td>
                                            <td>Rp. <?php echo e(number_format($tagihan->bayar, 0, ',', '.')); ?></td>
                                            <td>Rp. <?php echo e(number_format($tagihan->kembali, 0, ',', '.')); ?></td>
                                            <td><?php echo e($tagihan->petugas); ?></td>
                                        </tr>
                                        <?php
                                            $no++;
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--/ Layout Demo -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sbuhmpm/development/project_ivan/sendangguwo/materio-bootstrap-html-laravel-admin-template-free-v1.0.0/resources/views/content/menu-admin/riwayat-transaksi.blade.php ENDPATH**/ ?>