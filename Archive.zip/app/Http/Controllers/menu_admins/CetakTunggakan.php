<?php

namespace App\Http\Controllers\menu_admins;

use App\Http\Controllers\Controller;
use App\Models\CekTagihan;
use App\Models\Pelanggan;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CetakTunggakan extends Controller
{
    public function index()
    {
        Carbon::setLocale('id');
        $currentDate = Carbon::now();
        $currentMonthYear = $currentDate->format('F Y');
        $date = Carbon::createFromFormat('F Y', $currentMonthYear);

        $threeMonthsAgo = [];
        for ($i = 0; $i <= 3; $i++) {
            $fourMonthsAgo[] = $date->copy()->subMonths($i)->translatedFormat('F Y');
        }

        $tagihans = CekTagihan::join('pelanggans', 'pelanggans.id_pelanggan', '=', 'cek_tagihans.id_pelanggan')
            ->whereIn(DB::raw("CONCAT(bulan_tagihan, ' ', tahun_tagihan)"), $fourMonthsAgo)
            ->select('pelanggans.id_pelanggan', '')
            ->get();

        dd($tagihans);

        if ($tagihans) {
            foreach ($tagihans as $tagihan) {
            }
        }

        return view('content.menu-admin.cetak-tunggakan');
    }
}
