@extends('layouts/printLayout')

@section('title', 'Cetak Struk')

@section('content')
    <div style="width: 1000px; color:black;">
        <div style="text-align:center">
            <h4>Sumber Tirta Sendangguwo</h4>
        </div>
        <div class="d-flex">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th class="text-dark" style="width: 20px; border: 1px solid #000; padding: 0; text-align:center;">
                            No pgl</th>
                        <th class="text-dark" style="width: 200px; border: 1px solid #000; padding: 0; text-align:center;">
                            Nama</th>
                        <th class="text-dark" style="width: 30px; border: 1px solid #000; padding: 0; text-align:center;">
                            Maret</th>
                        <th class="text-dark" style="width: 30px; border: 1px solid #000; padding: 0; text-align:center;">
                            April
                        </th>
                        <th class="text-dark" style="width: 30px; border: 1px solid #000; padding: 0; text-align:center;">
                            Mei</sup>
                        </th>
                        <th class="text-dark" style="width: 30px; border: 1px solid #000; padding: 0; text-align:center;">
                            Juni</sup>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="text-dark" style="border: 1px solid #000; padding: 0;">

                        </td>
                        <td class="text-dark" style="border: 1px solid #000; padding: 0;">

                        </td>
                        <td class="text-dark" style="border: 1px solid #000; padding: 0;">

                        </td>
                        <td class="text-dark" style="border: 1px solid #000; padding: 0;">

                        </td>
                        <td class="text-dark" style="border: 1px solid #000; padding: 0;">

                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    {{-- <script>
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(function() {
                window.print();
            }, 1500);
        });
    </script> --}}
@endsection
